﻿using ArticulosBack.Domain;
using ArticulosBack.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArticulosBack.Services
{
    public class ServiceArticles
    {
        ArticlesRepository ArticulosRepo = new ArticlesRepository();

        public bool AgregarArticulo(Article articulo)
        {
            return ArticulosRepo.Agregar(articulo);
        }

        public bool BorrarArticulo(int id)
        {
            return ArticulosRepo.Borrar(id);
        }

        public List<Article> ConsultarArticulos()
        {
            return ArticulosRepo.Consultar();
        }

        public bool EditarArticulo(Article articulo)
        {
            return ArticulosRepo.Editar(articulo);
        }

        public Article ConsultaArticulo(int id)
        {
            return ArticulosRepo.ConsultarUno(id);
        }
    }
}
