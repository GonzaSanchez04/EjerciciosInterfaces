﻿using ArticulosBack.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArticulosBack.Interfaces
{
    public interface IAplication
    {
        bool Agregar(Article articulo);

        List<Article> Consultar();

        Article ConsultarUno(int id);

        bool Editar(Article articulo);

        bool Borrar(int id);
    }
}
