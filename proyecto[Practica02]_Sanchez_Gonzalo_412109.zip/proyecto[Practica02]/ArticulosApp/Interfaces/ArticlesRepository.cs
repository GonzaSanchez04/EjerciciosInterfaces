﻿using ArticulosBack.Domain;
using ArticulosBack.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ArticulosBack.Interfaces
{
    public class ArticlesRepository : IAplication
    {
        public bool Agregar(Article articulo)
        {
            bool aux = false;
            var lst = new List<SqlParameter>();
            lst.Add(new SqlParameter("@nombre", articulo.Nombre));
            lst.Add(new SqlParameter("@pre_unitario", articulo.PreUnitario));

            if (DataHelper.GetInstance().EjecutarDMLPA("SP_AGREGAR_ARTICULO", lst) != 0)
            {
                aux = true;
            }

            return aux;
        }

        public bool Borrar(int id)
        {
            bool aux = false;
            var lst = new List<SqlParameter>();
            lst.Add(new SqlParameter("@id", id));
            if (ConsultarUno(id).Activo == 1)
            {
                if (DataHelper.GetInstance().EjecutarDMLPA("SP_BORRAR_ARTICULO", lst) != 0)
                {
                    aux = true;
                }
            }
            

            return aux;
        }

        public List<Article> Consultar()
        {
            var lst = new List<Article>();
            DataTable tabla = DataHelper.GetInstance().EjecutarConsultaPA("SP_TRAER_ARTICULOS");

            foreach (DataRow row in tabla.Rows)
            {
                Article a = new Article();
                a.Codigo = Convert.ToInt32(row["id_articulo"]);
                a.Nombre = row["nombre"].ToString();
                a.PreUnitario = Convert.ToDecimal(row["pre_unitario"]);
                a.Activo = Convert.ToInt32(row["activo"]);
                lst.Add(a);
            }

            return lst;
        }

        public Article ConsultarUno(int id)
        {
            var articulo = new Article();
            var param = new List<SqlParameter>();
            param.Add(new SqlParameter("@id", id));

            DataTable tabla = DataHelper.GetInstance().EjecutarConsultaPA("SP_CONSULTA_ARTICULO", param);
            foreach (DataRow row in tabla.Rows)
            {
                articulo.Codigo = Convert.ToInt32(row["id_articulo"]);
                articulo.Nombre = row["nombre"].ToString();
                articulo.PreUnitario = Convert.ToDecimal(row["pre_unitario"]);
                articulo.Activo = Convert.ToInt32(row["activo"]);
            }

            return articulo;
        }

        public bool Editar(Article articulo)
        {
            bool aux = false;
            var lst = new List<SqlParameter>();
            lst.Add(new SqlParameter("@codigo", articulo.Codigo));
            lst.Add(new SqlParameter("@nombre", articulo.Nombre));
            lst.Add(new SqlParameter("@pre_unitario", articulo.PreUnitario));
            lst.Add(new SqlParameter("@activo", articulo.Activo));

            if (DataHelper.GetInstance().EjecutarDMLPA("SP_ACTUALIZAR_ARTICULO", lst) != 0 && ConsultarUno(articulo.Codigo).Activo == 1)
            {
                aux = true;
            }

            return aux;
        }
    }
}
