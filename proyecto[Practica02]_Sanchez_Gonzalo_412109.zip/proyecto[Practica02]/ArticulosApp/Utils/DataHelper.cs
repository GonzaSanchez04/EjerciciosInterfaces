﻿using Microsoft.Azure.Amqp.Framing;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArticulosBack.Utils
{
    public class DataHelper
    {
        private static DataHelper _instancia;
        private SqlConnection _conexion;

        private DataHelper()
        {
            _conexion = new SqlConnection(Properties.Resources.CadenaConexion412109);
        }

        public static DataHelper GetInstance()
        {
            if (_instancia == null)
                _instancia = new DataHelper();

            return _instancia;
        }

        public DataTable EjecutarConsultaPA(string sp, List<SqlParameter> parametros = null)
        {
            DataTable t = new DataTable();
            try
            {
                _conexion.Open();
                var cmd = new SqlCommand(sp, _conexion);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                if (parametros != null)
                {
                    foreach (var param in parametros)
                        cmd.Parameters.AddWithValue(param.ParameterName, param.Value);
                }

                t.Load(cmd.ExecuteReader());
                _conexion.Close();
            }
            catch (SqlException)
            {
                t = null;
            }

            return t;
        }

        public int EjecutarDMLPA(string sp, List<SqlParameter> parametros)
        {
            int rows;
            try
            {
                _conexion.Open();
                var cmd = new SqlCommand(sp, _conexion);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                if (parametros != null)
                {
                    foreach (var param in parametros)
                        cmd.Parameters.AddWithValue(param.ParameterName, param.Value);
                }

                rows = cmd.ExecuteNonQuery();
                _conexion.Close();
            }
            catch (SqlException)
            {
                rows = 0;
            }

            return rows;
        }

        public SqlConnection DevolverConexion()
        {
            return _conexion;
        }
    }
}
