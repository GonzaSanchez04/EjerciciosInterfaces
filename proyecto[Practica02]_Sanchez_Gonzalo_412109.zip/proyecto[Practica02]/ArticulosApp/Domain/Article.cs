﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArticulosBack.Domain
{
    public class Article
    {
        public int Codigo { get; set; }

        public string? Nombre { get; set; }

        public decimal PreUnitario { get; set; }

        public int Activo { get; set; }
    }
}
