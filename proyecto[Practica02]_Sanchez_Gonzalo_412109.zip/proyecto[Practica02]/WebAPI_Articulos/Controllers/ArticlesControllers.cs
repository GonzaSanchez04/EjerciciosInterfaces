using ArticulosBack.Domain;
using ArticulosBack.Services;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI_Articulos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArticulosController : ControllerBase
    {
        ServiceArticles ServicioA = new ServiceArticles();

        [HttpGet("TraerArticulos")]

        public IActionResult GetArticulos()
        {
            return Ok(ServicioA.ConsultarArticulos());
        }

        [HttpGet("{id}")]

        public IActionResult GetArticulos(int id)
        {
            if (ServicioA.ConsultaArticulo(id).Codigo != 0)
            {
                return Ok(ServicioA.ConsultaArticulo(id));
            }
            else
            {
                return BadRequest("Error al encontrar el articulo");
            }
        }

        [HttpPost("AgregarArticulo")]

        public IActionResult AddArticulo(Article articulo)
        {
            if (ServicioA.AgregarArticulo(articulo))
            {
                return Ok("Articulo a�adido con exito!");
            }
            else
            {
                return BadRequest("Error al ingresar el articulo");
            }
        }

        [HttpDelete("BorrarArticulo/{id}")]

        public IActionResult AddArticulo(int id)
        {
            if (ServicioA.BorrarArticulo(id))
            {
                return Ok("Articulo eliminado con exito!");
            }
            else
            {
                return BadRequest("Error al borrar el articulo");
            }
        }

        [HttpPost("ActualizarArticulo")]

        public IActionResult UpdateArticulo(Article articulo)
        {
            if (ServicioA.EditarArticulo(articulo))
            {
                return Ok("Articulo actualizado con exito!");
            }
            else
            {
                return BadRequest("Error al actualizar el articulo");
            }
        }

    }
}
